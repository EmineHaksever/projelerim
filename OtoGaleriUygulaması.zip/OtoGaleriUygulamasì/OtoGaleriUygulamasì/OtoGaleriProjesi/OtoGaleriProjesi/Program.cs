﻿using System;

namespace OtoGaleriProjesi
{
    class Program
    {
        static void Main(string[] args)
        {
            new Uygulama().Calistir();
        }
    }
}
