﻿using System;

namespace OkulYonetimUygulamasi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new Uygulama().Calistir();
        }
    }
}
